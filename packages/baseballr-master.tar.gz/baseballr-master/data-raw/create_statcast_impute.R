statcast_impute <- read.csv("D:/GitHub-Data/baseballr/data-raw/statcast_impute.csv")

usethis::use_data(statcast_impute,overwrite = TRUE)